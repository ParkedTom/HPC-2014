#!/bin/bash
../local/bin/lame --silent --mp3input --decode -t  $1 -
