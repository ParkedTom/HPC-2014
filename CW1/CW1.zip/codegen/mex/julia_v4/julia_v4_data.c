/*
 * julia_v4_data.c
 *
 * Code generation for function 'julia_v4_data'
 *
 * C source code generated on: Tue Feb 04 20:09:16 2014
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "julia_v4.h"
#include "julia_v4_data.h"

/* Variable Definitions */
const volatile char_T *emlrtBreakCheckR2012bFlagVar;

/* End of code generation (julia_v4_data.c) */
