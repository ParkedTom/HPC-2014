/*
 * _coder_julia_v4_1_info.h
 *
 * Code generation for function 'julia_v4_1'
 *
 * C source code generated on: Tue Feb  4 00:21:00 2014
 *
 */

#ifndef ___CODER_JULIA_V4_1_INFO_H__
#define ___CODER_JULIA_V4_1_INFO_H__
/* Include files */
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"


/* Function Declarations */
extern const mxArray *emlrtMexFcnResolvedFunctionsInfo(void);

#endif
/* End of code generation (_coder_julia_v4_1_info.h) */
