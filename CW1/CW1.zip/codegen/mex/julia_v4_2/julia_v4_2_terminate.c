/*
 * julia_v4_2_terminate.c
 *
 * Code generation for function 'julia_v4_2_terminate'
 *
 * C source code generated on: Tue Feb  4 00:24:22 2014
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "julia_v4_2.h"
#include "julia_v4_2_terminate.h"

/* Function Definitions */
void julia_v4_2_atexit(emlrtStack *sp)
{
  emlrtCreateRootTLS(&emlrtRootTLSGlobal, &emlrtContextGlobal, NULL, 1);
  sp->tls = emlrtRootTLSGlobal;
  emlrtEnterRtStackR2012b(sp);
  emlrtLeaveRtStackR2012b(sp);
  emlrtDestroyRootTLS(&emlrtRootTLSGlobal);
}

void julia_v4_2_terminate(emlrtStack *sp)
{
  emlrtLeaveRtStackR2012b(sp);
  emlrtDestroyRootTLS(&emlrtRootTLSGlobal);
}

/* End of code generation (julia_v4_2_terminate.c) */
