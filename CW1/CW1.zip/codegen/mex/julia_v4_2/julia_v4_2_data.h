/*
 * julia_v4_2_data.h
 *
 * Code generation for function 'julia_v4_2_data'
 *
 * C source code generated on: Tue Feb  4 00:24:22 2014
 *
 */

#ifndef __JULIA_V4_2_DATA_H__
#define __JULIA_V4_2_DATA_H__
/* Include files */
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "mwmathutil.h"

#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "blas.h"
#include "rtwtypes.h"
#include "julia_v4_2_types.h"

/* Variable Declarations */
extern const volatile char_T *emlrtBreakCheckR2012bFlagVar;
extern emlrtRSInfo e_emlrtRSI;
extern emlrtRSInfo f_emlrtRSI;
extern emlrtRSInfo g_emlrtRSI;
extern emlrtRSInfo h_emlrtRSI;
extern emlrtRSInfo i_emlrtRSI;
extern emlrtRSInfo j_emlrtRSI;
#endif
/* End of code generation (julia_v4_2_data.h) */
