/*
 * mpower.c
 *
 * Code generation for function 'mpower'
 *
 * C source code generated on: Tue Feb  4 00:26:36 2014
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "julia_v4_3.h"
#include "mpower.h"
#include "power.h"

/* Function Definitions */
creal_T mpower(const creal_T a)
{
  return power(a);
}

/* End of code generation (mpower.c) */
